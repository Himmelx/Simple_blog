create definer = root@localhost view cubuy as
select `11912991114熊兴禄`.`drug`.`Mname`  AS `Mname`,
       `11912991114熊兴禄`.`drug`.`Mprice` AS `Mprice`,
       `11912991114熊兴禄`.`buy`.`Bnumber` AS `Bnumber`,
       `11912991114熊兴禄`.`buy`.`Bdate`   AS `Bdate`
from ((`11912991114熊兴禄`.`customer` join `11912991114熊兴禄`.`buy` on ((`11912991114熊兴禄`.`customer`.`Cno` = `11912991114熊兴禄`.`buy`.`Cno`)))
         join `11912991114熊兴禄`.`drug` on ((`11912991114熊兴禄`.`buy`.`Mno` = `11912991114熊兴禄`.`drug`.`Mno`)))
where (`11912991114熊兴禄`.`drug`.`Mname` = '李红');

